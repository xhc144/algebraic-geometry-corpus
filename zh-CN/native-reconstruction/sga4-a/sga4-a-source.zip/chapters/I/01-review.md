# Exposé I §§0–4 翻译检查记录

状态：所分配正文已全部译出；完成一轮译者对照检查，尚未经独立审校。此文件是内部检查记录，不属于书籍正文。

- 来源：`/tmp/01-sections-0-4-source.tex`，由已校验的仓库 ZIP 内 `release/04_SGA4_EN_COMPLETE_READER.tex` 提取。
- 精确范围：Exposé I §0 `I.sec0` 至 §4.3.3 末尾；含 §§1–4 所有定义、命题、推论、引理、例、证明、注释及脚注。对应第一篇扁平稿第 586–1556 行，输入 971 行。
- 输出：`chapters/I/01-sections-0-4.tex`，855 行；中文重排换行不代表删节。
- 输入 SHA-256：`d0730e49c13dacba23c9e5c9d78cbcee0a2395e2a059a1605183afd1dddc6b65`。
- 输出 SHA-256：`7b0a08696a40754aa58a4265c8ad10c788c7d8fa7043733e16d6b2688ee2d1be`。

机械对照结果：52 个 `etiquette` 标签、11 个 `hyperref` 目标、48 个环境起止对、21 个原页码标记、7 个 Xy-pic 交换图、33 个 `item`、3 个 `nde` 与 1 个显式 `footnote` 均保留，标签与链接目标相同。数学片段忽略空白后的多重集仅有以下明确差别，其余公式片段相同（中文语序可能改变片段出现次序）：

1. 构造–定义 1.3 的英文原稿写作 `we have $a$ canonical isomorphism`。其中 `$a$` 是误入数学模式的英语冠词；译作“有一个典范同构”，未将其当作变量。因而粗糙的美元数学片段计数由 677 变为 676，实际公式无删减。
2. 同一处关系描述的行间式末尾 `\mbox{»}` 译为中文闭引号 `\mbox{”}`，公式本体未改。

底稿异常与审校提示：

- §0 对宇宙要求非空与 Bourbaki 附录定义的冲突，是底稿现成编者注，已完整翻译，未消除冲突。
- §0 把 0 及可数无限基数也称作强不可达，是本书在此采用的约定，已保留，不按现代常见约定擅改。
- §0 原稿的 `𝒰(c(𝒰)\leq\card(𝒰))` 紧接写法已按原数学代码保留，未将其中括号擅自拆成另一公式。
- 例 2.7.1 关于“两个对象的和及平行箭头对余核可表示则滤过”的表述未明确加非空条件；空范畴的边界情形可进一步对法文核验，译文未补条件。
- 推论 3.5 证明中引用定义 1.2，按底稿保留，未代改交叉引用。

编译与视觉状态：本分片由主代理集成后统一编译；译者未运行此分片的独立编译，未声称 PDF、字体或溢出检查通过。分片内部没有未译占位段落或待续标记；人名均保留原文拼写。正文内新增首次出现的英文学术词仅为双语术语说明，保留的 `source`、`Fonct` 为底稿公式中的算子名称。

Root independent-review correction: the definition of c(U) in§0 now separates the universe U from the parenthetical bound c(U)≤card(U), so the Chinese says “the supremum of cardinalities of elements of U”. The original selected TeX put U and the bound in one math span; treating the whole span as a noun made the Chinese ambiguous. The independent reviewer checked original scan physical p.19, printed p.3. All symbols remain; only sentence/math-span grouping changed.
