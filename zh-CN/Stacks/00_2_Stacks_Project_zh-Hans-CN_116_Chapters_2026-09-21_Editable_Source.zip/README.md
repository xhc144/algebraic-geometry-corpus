# Complete editable Mainland Simplified Chinese Stacks translation

This unofficial AI-assisted translation contains all 116 chapters of the pinned
upstream Stacks commit a04446e57ec1fbc252a871afcec7752fb2807b14. It is not an
official edition or a comprehensively human-reviewed translation. Expert
corrections are welcome. Translation-choice review is a separate ongoing task.

The src/ directory is the exact modular source tree used by the corresponding
reader. No live producer folders, caches, page images, or private authorities
are required. ASSEMBLY.json binds all 123 source/support files. COPYING and the
in-reader license preserve the inherited GFDL 1.2-or-later terms.

## Build

Install PowerShell, XeLaTeX and BibTeX (MiKTeX or a compatible TeX distribution),
Latin Modern fonts, Noto Serif CJK SC and Noto Sans CJK SC. The TeX distribution
must supply amsalpha.bst, amsmath/AMS fonts, fontspec, xeCJK, xypic, hyperref,
geometry, graphicx, multicol and verbatim, with their normal dependencies.
Keep the font versions and TeX toolchain fixed for byte-level reproduction.

On Windows, place xelatex and bibtex on PATH and run from this package:

    pwsh -NoProfile -File BUILD.ps1

The build acquires Global\InterlanguageTeXSlotV1 for the entire captured process
tree and all passes. It times out rather than interfering with another build.
It uses SOURCE_DATE_EPOCH=1789776000, FORCE_SOURCE_DATE=1 and TZ=UTC, and checks
exact PDF/auxiliary convergence within five TeX passes with a bibliography run.
It refuses to overwrite an earlier build attempt. Use a fresh extraction for
another full reproduction. The exact known math-font dump beginning with an
exclamation mark is not a TeX error; all actual fatal/missing-glyph diagnostics
remain failures. Layout/visual review is separate from successful compilation.

## Direct cumulative LaTeX

The separately downloadable cumulative .tex contains every chapter in full,
not a thin master. DIRECT_SOURCE_MANIFEST.json maps every retained byte span to
the modular inputs and accounts for the 120 expanded input directives.
To compile that direct file, place it beside src/stacks-project-book.cls and
src/my.bib (or add src/ to TEXINPUTS and BIBINPUTS) and use the same toolchain.
The modular src/reader.tex remains the exact released build entry point; the
assembled file is a byte-accounted alternative for reading and editing.

The Brauer revision has 31 attested terminology preferences, one punctuation
repair and one English section-reference localization. When LAYOUT_REPAIRS.json
is present it separately records optional line-break repairs, without changing
mathematical text. The valid synonym
replaced by the preferred term is not a mathematical error. Exact choices and
their source evidence are published in the repository's translation-choice log.
