# Chinese normalization revision, 21 September 2026

All 116 chapters of the pinned Stacks snapshot remain present (5,906 pages).
This is an unofficial AI-assisted translation, without comprehensive expert
human review. Expert corrections are warmly welcome; neither a successful
build nor full chapter coverage certifies the language as error-free.

## What changed and why

The [Brauer choice log](https://github.com/KokunoYumeto/stacks-zh-hans-cn/blob/zh-hans-cn-2026.09.21-normalization-r1/review/translation-choices/brauer-successor.md) explains
31 contextual occurrences of `斜域` changed to `除环`, plus an orphan parenthesis
and one English section-reference remnant. The terminology is an attested
editorial preference: `斜域` is a valid synonym, not an error. The consulted
specialist source and exact passage are linked in the log, with alternatives,
uncertainty and every affected occurrence. Evidence was obtained retrospectively.

Three unrelated typesetting repairs add nine optional math break tokens:

| Source result | Reader page | Repair |
| --- | ---: | --- |
| more-algebra-lemma-split-complex-regular | 1163 (printed 1083) | Allow the long Hom expression to wrap between its arguments. |
| etale-cohomology-theorem-zariski-fpqc-quasi-coherent | 3757 (printed 3677) | Allow the topology list to wrap at commas. |
| spaces-descent-definition-property-morphisms-local | 4469 (printed 4389) | Allow the topology list to wrap at commas. |

These defects were inherited from the previous reader. Fresh inspection
contradicted its historical no-clipping judgment, which is preserved as history,
not repeated as proof. Removing the nine added `\allowbreak` tokens restores
the prior source exactly. Mathematical text is unchanged by these repairs.
Front matter now states the actual complete chapter coverage, links the choice
index, and distinguishes translation normalization from upstream source errata.
Its 19 September date identifies the source-revision start, not publication day.

## What was checked

The 123 exact source/support files and 116 ordered chapter inputs were bound
before compilation. The complete reader converged byte-for-byte with its
reference auxiliaries; the recorder used the frozen source tree. The layout-only
successor reused an exact already-converged bibliography, then converged in two
passes. The downloadable source ZIP supplies a fresh-from-scratch build script,
not private auxiliary seeds.

All 5,906 pages were checked for text bounds, empty extraction, replacement
characters, link geometry and internal destinations. All 68,504 links passed;
all 51 fonts are embedded. Exactly 5,895 pages render identically to the previous
reader at 120 dpi and inherit its bounded agent visual review. The 11 changed
pages were freshly rendered by Poppler at 144 dpi and individually inspected.
No blocking layout finding remains in these checks. This is not human review.

Remaining limitations: the PDF is untagged; 13 legacy math/diagram fonts lack
ToUnicode. The inherited source's literal editorial placeholders are not
silently removed. Translation normalization and source-errata review are
separate ongoing processes; this batch does not audit all wording.

## Sources and navigation

The [release](https://github.com/KokunoYumeto/stacks-zh-hans-cn/releases/tag/zh-hans-cn-2026.09.21-normalization-r1) orders the reader PDF,
direct full-text cumulative LaTeX and complete modular source ZIP first, then
review evidence. The source ZIP contains all required project inputs, the
bibliography, class/macros, license and bounded build instructions. It excludes
page-image caches. The direct LaTeX has all 120 input directives expanded with
an exact byte-span reconstruction map. GNU FDL 1.2-or-later terms are inherited.

The existing interconnected HTML reader is a separate delivery pipeline. This
frozen revision is suitable as its input; this release does not claim that a
complete public CJK HTML reader has already been deployed.
