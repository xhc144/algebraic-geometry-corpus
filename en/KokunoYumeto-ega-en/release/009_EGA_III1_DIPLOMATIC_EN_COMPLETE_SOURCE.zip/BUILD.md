# Reproducing the edition

Run the commands from the root of the extracted archive. Use only one TeX engine at a time and enforce the stated memory limit.

The file under direct/ is cumulative and has no local source-file dependencies.

To rebuild from the exact editable source tree, use the commands below.

The original controlled build used `SOURCE_DATE_EPOCH=946684800`, `FORCE_SOURCE_DATE=1`, `TZ=UTC`, the named mutex `Global\InterlanguageTeXSlotV1`, and an aggregate private-memory limit of `3221225472` bytes. These constraints must be retained on the production machine.

```powershell
$env:SOURCE_DATE_EPOCH='946684800'
$env:FORCE_SOURCE_DATE='1'
$env:TZ='UTC'
New-Item -ItemType Directory -Force -Path '.\build' | Out-Null
Copy-Item -LiteralPath '.\support\EGA_III1_MODULAR_CANONICAL.bbl' -Destination '.\build\EGA_III1_EN_DIPLOMATIC_READER.bbl'
Push-Location 'source'
latexmk -pdf -interaction=nonstopmode -halt-on-error -file-line-error -recorder -bibtex- -outdir='..\build' 'EGA_III1_EN_DIPLOMATIC_READER.tex'
Pop-Location
```

The direct cumulative file is `direct/EGA_III1_EN_DIPLOMATIC_READER.tex`. Build it with the same engine and without BibTeX.

```powershell
New-Item -ItemType Directory -Force -Path '.\build-direct' | Out-Null
Push-Location 'direct'
latexmk -pdf -interaction=nonstopmode -halt-on-error -file-line-error -recorder -bibtex- -outdir='..\build-direct' 'EGA_III1_EN_DIPLOMATIC_READER.tex'
Pop-Location
```
