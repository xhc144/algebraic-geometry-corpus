# Elements of Algebraic Geometry III, Part One — diplomatic edition

Chapter 0, §§8–13; Chapter III, §§1–5; bibliography continuation; index of notation; terminological index; table of contents.

File order: reader PDF, direct cumulative LaTeX source, then the complete reproducible source ZIP.

1. `010_EGA_III1_EN_DIPLOMATIC_READER.pdf`
2. `011_EGA_III1_EN_DIPLOMATIC_READER.tex`
3. `012_EGA_III1_EN_DIPLOMATIC_READER_SOURCE.zip`

The archive preserves the exact branch source tree byte for byte and adds the flattened cumulative file, build instructions, and a cryptographic manifest.

## AI provenance

Inherited AI transcription, translation, and correction work is present, but its exact model and effort level are not established by the retained durable evidence. Successor adoption, diplomatic reconstruction, assembly, correction, and audit were performed by OpenAI Codex — GPT-5.6 Sol at Ultra effort. Vietnamese unit ega0-10 was also translated by that model at that effort. No human editing, review, or approval is claimed.
