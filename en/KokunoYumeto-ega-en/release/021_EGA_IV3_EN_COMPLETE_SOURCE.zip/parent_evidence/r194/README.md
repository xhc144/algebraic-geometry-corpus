# Elements of Algebraic Geometry — EGA IV, Part Three — English edition

By Alexander Grothendieck and Jean Dieudonné.

Complete editable source for the accompanying 193-page English reader.
This corrected/current edition is distinct from the original-language French
printed witness and from separately labelled printed-witness translations.

## Read, edit and reproduce

The PDF is followed by a directly downloadable complete LaTeX file and this
reproducible source ZIP. `native/` preserves the modular project;
`direct/EGA_IV3_English_Standalone_Reader.tex` contains the full assembled text, not a thin input-only master.
Required local styles, macros, reference helpers, bibliography and build scripts
are included and inventoried in `MANIFEST.json`. Standard distribution packages
and fonts are listed in `RUNTIME_DEPENDENCIES.json`; engine identities and the
fixed build epoch are in `SOURCE_FRONTIER.json`.

With PowerShell 7 and the recorded MiKTeX environment, run:

```powershell
pwsh -NoProfile -File ./BUILD.ps1 -PdfLatex /path/to/pdflatex.exe -BibTeX /path/to/bibtex.exe -SourceForm native -OutputDirectory ./build_native
```

Use `-SourceForm direct` and a different, new output directory for the assembled
file. The script serializes the complete TeX/BibTeX process tree and deterministic
replay under a machine-wide mutex, with a 3,221,225,472-byte aggregate private-memory
cap. Automatic package installation is disabled. Native and assembled source forms produce identical PDF bytes.

## Editorial scope and provenance

This edition retains the full exposition, original mathematical numbering,
printed-page locators and linked references. It includes the accepted English
corrections through the source frontier recorded in `SOURCE_FRONTIER.json`,
including the accumulated reference, notation and proof repairs. The source
distinction between faithful printed readings and justified current repairs is
preserved in the Canon evidence. Later reports remain separate pending work;
this release does not claim that the entire multilingual backlog is closed.

Deterministic replay, actual loaded project inputs, source inverses, affected
formulas/references and bounded complete-page visual checks are recorded in
`VALIDATION.json`. The cumulative reader and the affected standalone readers
contain the same accepted English corrections.

Reader/source assembly, bounded validation and render/link repairs:
OpenAI Codex — GPT-6 Astra, Ultra effort. Inherited III-1 adoption, diplomatic
reconstruction, assembly, correction and audit: GPT-5.6 Sol, Ultra effort.
These credits do not attribute the entire earlier translation to either model.
Inherited provenance is retained in the source evidence and edition history;
not every historical model/effort is established. No independent human editing,
review, approval or certification is claimed.

## Editions and access

- English edition: https://doi.org/10.5281/zenodo.21921591
- English source and releases: https://github.com/KokunoYumeto/ega-en
- Separate French printed-witness edition: https://doi.org/10.5281/zenodo.21921588
- French source and releases: https://github.com/KokunoYumeto/ega-fr

Earlier public versions remain accessible. Every released document is paired
with direct complete editable LaTeX and a full-source ZIP.
