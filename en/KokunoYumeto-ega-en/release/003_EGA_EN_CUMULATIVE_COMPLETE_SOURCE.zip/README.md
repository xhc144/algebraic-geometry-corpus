# EGA 0–IV complete linked English reader — editable English sources

The original work is by Alexandre Grothendieck and Jean Dieudonné. This complete corrected/current source project accompanies the 1,411-page reader published on 2 October 2026. It includes the admitted corrections in its pinned source basis; it does not claim that the multilingual correction backlog is complete.

## Read and edit

The modular project is in `native/`; `direct/00_EGA_EN_CUMULATIVE.tex` contains the complete assembled LaTeX text, not just references to private chapter files. Both forms include their required project styles, macros and bibliographies. The release also offers the assembled text as a separate direct download. Standard TeX packages and fonts remain external distribution dependencies, recorded in `RUNTIME_DEPENDENCIES.json`.

## Reproduce the reader

Use PowerShell on Windows with pdfLaTeX and BibTeX. From this package directory, run:

`./BUILD.ps1 -PdfLatex <pdflatex.exe> -BibTeX <bibtex.exe> -SourceForm native -OutputDirectory <new-directory-inside-this-package>`

Use `-SourceForm direct` for the assembled source. The supplied worker runs independent primary and replay builds, disables automatic package installation, holds `Global\InterlanguageTeXSlotV1` throughout the captured TeX processes, and caps aggregate private memory at 3,221,225,472 bytes. Install the standard distribution dependencies before building.

## Validation and provenance

The PDF bytes are the accepted deterministic reader; this packaging step changes no compiled source or PDF. `RELEASE_VALIDATION.json` gives the final status, while `SOURCE_FRONTIER.json` and `parent_evidence/` retain the historical source and repair records. Preparatory statuses there describe their original stage, not the final reader. Public `workspace:/` and `user-home:/` locators are historical references, not private build dependencies.

The native project reproduces the released PDF exactly. The assembled source has also passed independent replay, full-page text and protected-page checks, and navigation validation. One inherited native/direct typography and link-box difference remains at displayed page 700, without a text or mathematical difference. The complete text of the previously missing page-827 clause is restored. The direct inline boxing guards and heading-anchor repair are documented reversibly.

Reader/source assembly, correction integration, bounded validation, and rendering and navigation repairs for this update: OpenAI Codex — GPT-6 Astra, Ultra effort. Retained III-1 adoption, diplomatic reconstruction, assembly, correction and audit: GPT-5.6 Sol, Ultra effort. These credits describe the recorded work, not the entire inherited translation. Earlier provenance remains in the source evidence and edition history; not every historical model or effort level is established. No independent human editing, review, approval or certification is implied.

## Related editions

- [English edition and stable DOI](https://doi.org/10.5281/zenodo.21921591)
- [English sources and release history](https://github.com/KokunoYumeto/ega-en)
- [French diplomatic and corrected editions](https://doi.org/10.5281/zenodo.21921588)
- [Previous English edition](https://zenodo.org/records/23054441)

Original rights and inherited licence notices remain applicable; this source package grants no new rights over the original text.
