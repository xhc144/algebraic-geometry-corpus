# Elements of Algebraic Geometry: III, Part Two in English

By Alexander Grothendieck and Jean Dieudonné.

This package contains the complete editable source for the accompanying
84-page English reader. It includes both the native modular project and
a complete directly assembled LaTeX file, not a thin master or a changes-only
patch. It is the maintained corrected/current English edition; French printed
witnesses and separately published diplomatic editions remain distinct.

## Read, edit and reproduce

- `native/` contains every included body, local macro, reference helper and
  bibliography needed by the native project.
- `direct/EGA_III2_English_Standalone_Reader.tex` contains the complete assembled document.
- `direct/the.bib` supplies the bibliography when required.
- `BUILD.ps1` and `build_support/` reproduce the guarded build. No external
  project figures or unpublished chapter inputs are required.
- `MANIFEST.json` identifies every payload; `SOURCE_FRONTIER.json` identifies
  the source and engine versions; `RUNTIME_DEPENDENCIES.json` identifies the
  actual standard-distribution files loaded during the verified builds.

Install PowerShell 7 and a complete MiKTeX or TeX Live distribution. Standard
classes, packages and fonts remain dependencies under their own licences.
Exact PDF bytes require the pinned engine, format, font and package versions.

```powershell
pwsh -NoProfile -File ./BUILD.ps1 -PdfLatex /path/to/pdflatex.exe -BibTeX /path/to/bibtex.exe
```

Use `-SourceForm direct` with a new `-OutputDirectory` to build the complete
assembled file. The script refuses to overwrite prior builds. It takes the
machine-wide TeX mutex, makes two sequential six-pass builds (with BibTeX when
required), verifies final diagnostics and replay, and enforces a captured-tree
memory cap of 3,221,225,472 bytes. Automatic package installation is disabled.

Native and directly assembled sources have identical text, decoded page streams, fonts, page geometry and internal links on every page. Each source form independently reproduces its own PDF bytes across two six-pass builds.

The native reader passed the source, replay, text, font, internal-link and
bounded visual checks recorded in `VALIDATION.json`. These checks are not a
claim that every mathematical assertion has been independently certified.

## Edition and provenance

This source snapshot is EGA-CANON-QUEUE-20260926-R128. It does not silently include later
incoming reports. R128 assembly, deterministic builds and bounded QA were
performed by OpenAI Codex - GPT-6 Astra, Ultra effort, as bound to the recorded
runtime evidence in `PROVENANCE.json`. This is not an attribution of the entire
inherited translation to one model, and no human editing or approval is implied.
Earlier translation/correction provenance remains in the edition history.

English edition: https://doi.org/10.5281/zenodo.21921591
Repository and release history: https://github.com/KokunoYumeto/ega-en

Public access to earlier editions is preserved. The reader PDF, complete direct
LaTeX and full-source ZIP are paired in the same edition lineage. The native
source ZIP governs exact reproduction; public inventory and anonymous download
verification are recorded separately after publication.
