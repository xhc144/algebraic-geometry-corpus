# SGA 7 II - Monodromy Groups in Algebraic Geometry

Complete editable English edition, Exposes X-XXII. Original authors and redactors remain credited in the text. The 28 September 2026 correction integration, source assembly and reader checks were performed by OpenAI Codex - GPT-6 Astra, Ultra effort. Earlier translation attribution remains in the inherited edition. No independent human review is claimed.

The native/ directory contains the complete master and all 183 component inputs. Diagrams, formulae and bibliography are in those files; the build loads no additional project-specific styles, figures or data. Standard LaTeX packages/fonts are supplied by the TeX distribution; STANDARD_TEX_DEPENDENCIES.json lists the observed distribution inputs.

Compile native/SGA7_II_English_source_first_workpass.tex with pdfLaTeX three times. The verified environment was MiKTeX 26.5 / pdfTeX 1.40.29, LaTeX2e 2025-11-01, SOURCE_DATE_EPOCH=1790294400, FORCE_SOURCE_DATE=1, TZ=UTC. Use -no-shell-escape -interaction=nonstopmode -halt-on-error -recorder.

SGA7II_English_Cumulative.tex directly contains the entire text and preamble. It uses filecontents* to materialize its embedded inputs, preserving native input boundaries. To reproduce the exact released PDF bytes, copy this file into a fresh empty directory under the native master filename above and compile there three times. Native, independent replay and this direct-file compilation were byte-identical. The native modular tree is retained for editing.

The inherited README and self-excluding source manifest are preserved under historical/; the current SOURCE_MANIFEST.json supersedes their inventory. This source package contains no generated PDF, build cache, private scan or unrelated evidence.

English edition: https://doi.org/10.5281/zenodo.21925497

Original-language Canon: https://doi.org/10.5281/zenodo.20410947

GitHub: https://github.com/KokunoYumeto/sga-en
