# SGA 4½ English reader source

Primary master: `SGA4half_English_Reader_1_to_8.tex`.

This ZIP contains the active editable source closure only.  Generated PDFs, auxiliary files, logs, private witnesses, and scratch directories are excluded.
The self-excluding `SOURCE_MANIFEST.csv` hashes every admitted editable file.
