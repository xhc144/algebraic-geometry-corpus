[CmdletBinding()]
param(
    [switch]$Build,
    [string]$OutputDirectory
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

$masterName = 'SGA4half_English_Reader_1_to_8.tex'
$manifestName = 'reader-components-1-to-8.txt'
$masterPath = Join-Path $PSScriptRoot $masterName
$manifestPath = Join-Path $PSScriptRoot $manifestName
$componentsRoot = [IO.Path]::GetFullPath((Join-Path $PSScriptRoot 'components')).TrimEnd('\') + '\'
$expectedComponents = 1..8 | ForEach-Object {
    'components/sga4half_{0}_en.tex' -f $_
}
$expectedChapterLabels = @('I', 'II', 'III', 'IV', 'V', 'VI', 'VII', 'VIII')

foreach ($requiredPath in @($masterPath, $manifestPath, (Join-Path $PSScriptRoot 'sga-style.sty'), (Join-Path $PSScriptRoot 'sga-sources.bib'))) {
    if (-not (Test-Path -LiteralPath $requiredPath -PathType Leaf)) {
        throw "Required reader file is missing: $requiredPath"
    }
}

$manifestComponents = @(
    Get-Content -LiteralPath $manifestPath |
        ForEach-Object { $_.Trim() } |
        Where-Object { $_ -and -not $_.StartsWith('#') } |
        ForEach-Object { $_.Replace('\', '/') }
)

if ($manifestComponents.Count -ne $expectedComponents.Count) {
    throw "Manifest must contain exactly eight component paths; found $($manifestComponents.Count)."
}

for ($index = 0; $index -lt $expectedComponents.Count; $index++) {
    if ($manifestComponents[$index] -cne $expectedComponents[$index]) {
        throw "Manifest position $($index + 1) must be '$($expectedComponents[$index])', not '$($manifestComponents[$index])'."
    }
}

$masterText = Get-Content -LiteralPath $masterPath -Raw
$masterInputs = @(
    [regex]::Matches($masterText, '\\input\{([^}]+)\}') |
        ForEach-Object { $_.Groups[1].Value.Replace('\', '/') }
)

if ($masterInputs.Count -ne $expectedComponents.Count) {
    throw "Reader master must input exactly eight components; found $($masterInputs.Count)."
}

for ($index = 0; $index -lt $expectedComponents.Count; $index++) {
    if ($masterInputs[$index] -cne $expectedComponents[$index]) {
        throw "Reader master input position $($index + 1) must be '$($expectedComponents[$index])', not '$($masterInputs[$index])'."
    }
}

$placeholderPattern = '(?im)(^\s*%?\s*(?:TODO|FIXME|TBD|PLACEHOLDER)\b|\b(?:translation pending|not yet translated|draft stub|à traduire|a traduire)\b)'
$componentReport = foreach ($index in 0..($manifestComponents.Count - 1)) {
    $relativePath = $manifestComponents[$index]
    $fullPath = [IO.Path]::GetFullPath((Join-Path $PSScriptRoot $relativePath))

    if (-not $fullPath.StartsWith($componentsRoot, [StringComparison]::OrdinalIgnoreCase)) {
        throw "Manifest entry escapes the components directory: $relativePath"
    }
    if (-not (Test-Path -LiteralPath $fullPath -PathType Leaf)) {
        throw "Component is missing: $relativePath"
    }

    $item = Get-Item -LiteralPath $fullPath
    if ($item.Length -lt 1024) {
        throw "Component is unexpectedly small ($($item.Length) bytes): $relativePath"
    }

    $componentText = Get-Content -LiteralPath $fullPath -Raw
    if ([regex]::IsMatch($componentText, $placeholderPattern)) {
        throw "Component contains an unfinished-work marker: $relativePath"
    }
    if ([regex]::Matches($componentText, '(?m)^\s*\\chapter(?:\[[^\]]*\])?\{').Count -ne 1) {
        throw "Component must contain exactly one chapter command: $relativePath"
    }
    if (-not $componentText.Contains("\label{$($expectedChapterLabels[$index])}")) {
        throw "Component is missing its expected chapter label '$($expectedChapterLabels[$index])': $relativePath"
    }
    if ([regex]::IsMatch($componentText, '\\(?:documentclass|begin\{document\}|end\{document\})')) {
        throw "Component contains a document-level command: $relativePath"
    }

    $beginCount = [regex]::Matches($componentText, '\\begin\{').Count
    $endCount = [regex]::Matches($componentText, '\\end\{').Count
    if ($beginCount -ne $endCount) {
        throw "Component has unequal begin/end counts ($beginCount/$endCount): $relativePath"
    }

    [PSCustomObject]@{
        Position = $index + 1
        Component = $relativePath
        Bytes = $item.Length
        Sha256 = (Get-FileHash -LiteralPath $fullPath -Algorithm SHA256).Hash
    }
}

$componentReport | Format-Table -AutoSize
Write-Host 'CHECK PASSED: the reader master and manifest contain structurally ready components I--VIII in exact order.'

if (-not $Build) {
    Write-Host 'No compilation requested. Re-run with -Build only after every translation/QA lane has declared completion.'
    return
}

$pdflatex = Get-Command pdflatex -ErrorAction Stop
$bibtex = Get-Command bibtex -ErrorAction Stop

if ([string]::IsNullOrWhiteSpace($OutputDirectory)) {
    $stamp = Get-Date -Format 'yyyyMMdd-HHmmss'
    $OutputDirectory = Join-Path $PSScriptRoot "build/SGA4half_English_Reader_1_to_8-$stamp"
}
$resolvedOutputDirectory = [IO.Path]::GetFullPath($OutputDirectory)

if (Test-Path -LiteralPath $resolvedOutputDirectory) {
    throw "Refusing to overwrite an existing build directory: $resolvedOutputDirectory"
}
New-Item -ItemType Directory -Path $resolvedOutputDirectory | Out-Null

$jobName = [IO.Path]::GetFileNameWithoutExtension($masterName)
$latexArguments = @(
    '-interaction=nonstopmode'
    '-halt-on-error'
    '-file-line-error'
    "-output-directory=$resolvedOutputDirectory"
    $masterName
)
$previousBibInputs = $env:BIBINPUTS
$env:BIBINPUTS = "$PSScriptRoot;$previousBibInputs"

function Invoke-CheckedCommand {
    param(
        [Parameter(Mandatory = $true)][string]$Executable,
        [Parameter(Mandatory = $true)][string[]]$Arguments
    )
    & $Executable @Arguments
    if ($LASTEXITCODE -ne 0) {
        throw "Command failed with exit code ${LASTEXITCODE}: $Executable $($Arguments -join ' ')"
    }
}

Push-Location -LiteralPath $PSScriptRoot
try {
    Invoke-CheckedCommand -Executable $pdflatex.Source -Arguments $latexArguments
    Push-Location -LiteralPath $resolvedOutputDirectory
    try {
        Invoke-CheckedCommand -Executable $bibtex.Source -Arguments @($jobName)
    }
    finally {
        Pop-Location
    }
    Invoke-CheckedCommand -Executable $pdflatex.Source -Arguments $latexArguments
    Invoke-CheckedCommand -Executable $pdflatex.Source -Arguments $latexArguments
}
finally {
    Pop-Location
    $env:BIBINPUTS = $previousBibInputs
}

$pdfPath = Join-Path $resolvedOutputDirectory "$jobName.pdf"
if (-not (Test-Path -LiteralPath $pdfPath -PathType Leaf)) {
    throw "Build commands completed without producing the expected PDF: $pdfPath"
}

$pdfItem = Get-Item -LiteralPath $pdfPath
$pdfHash = (Get-FileHash -LiteralPath $pdfPath -Algorithm SHA256).Hash
Write-Host "BUILD PASSED: $pdfPath"
Write-Host "PDF bytes: $($pdfItem.Length)"
Write-Host "PDF SHA-256: $pdfHash"
