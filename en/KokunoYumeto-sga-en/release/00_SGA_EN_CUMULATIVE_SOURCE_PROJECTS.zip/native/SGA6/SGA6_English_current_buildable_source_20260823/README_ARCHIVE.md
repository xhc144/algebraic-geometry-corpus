# SGA6 maintained-English buildable source archive

This deterministic archive contains the active maintained-English source closure used on 2026-08-23.
It excludes generated PDFs, TeX auxiliaries, caches, QA renders, historical snapshots, credentials, and private absolute paths.

- Build driver: `02f_SGA6_English_Master.tex`
- Engine: `pdflatex`
- Selected source files: 15
- Included existing README/rights/build documents: 0
- Selection basis: exact local source closure recorded by the final successful maintained-English build recorder

Run the stated engine twice from the build driver's containing directory. A normal TeX installation supplies external package dependencies.
`BUILDABLE_CLOSURE_SHA256.tsv` records every other archive member by path, byte count, and SHA-256.

No separate README or rights file was present at this active source root; this archive makes no new rights claim.
