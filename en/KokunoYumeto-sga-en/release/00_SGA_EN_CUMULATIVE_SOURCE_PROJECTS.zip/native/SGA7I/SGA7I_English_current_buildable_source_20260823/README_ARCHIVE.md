# SGA7I maintained-English buildable source archive

This deterministic archive contains the active maintained-English source closure used on 2026-08-23.
It excludes generated PDFs, TeX auxiliaries, caches, QA renders, historical snapshots, credentials, and private absolute paths.

- Build driver: `SGA7_I_English_source_first_workpass.tex`
- Engine: `pdflatex`
- Selected source files: 189
- Included existing README/rights/build documents: 0
- Selection basis: active public source-first master plus its complete components directory

Run the stated engine twice from the build driver's containing directory. A normal TeX installation supplies external package dependencies.
`BUILDABLE_CLOSURE_SHA256.tsv` records every other archive member by path, byte count, and SHA-256.

No separate README or rights file was present at this active source root; this archive makes no new rights claim.
