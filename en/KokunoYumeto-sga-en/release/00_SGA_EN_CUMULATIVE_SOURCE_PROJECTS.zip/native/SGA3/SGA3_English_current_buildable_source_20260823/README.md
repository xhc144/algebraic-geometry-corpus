# SGA 3 — complete English native-reference-v2 local package

This no-overwrite package contains:

- the complete editable English source closure for the Introduction,
  Exposés I–XXVI, the Tome-I subject index, the Tome-III mathematical guide,
  and the terminal Tome-III index;
- the complete 1,482-page English PDF;
- native TeX diagram sources only (no active raster delivery);
- the co-current semantic-reference candidate, target, edge, structural, and
  residual ledgers;
- font, link, build, text-equivalence, and sampled visual-layout QA.

This is a local technical package.  It records no upload, DOI, publication,
public readback, or license grant.
