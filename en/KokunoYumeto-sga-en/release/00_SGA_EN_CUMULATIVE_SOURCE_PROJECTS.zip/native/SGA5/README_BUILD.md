# SGA 5 English reader source

Primary master: `SGA5_English_sync_workpass.tex`.

This ZIP contains the active editable source closure only.  Generated PDFs, auxiliary files, logs, private witnesses, and scratch directories are excluded.
The self-excluding `SOURCE_MANIFEST.csv` hashes every admitted editable file.
