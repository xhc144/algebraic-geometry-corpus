# SGA 4 proper English source bundle R8

This bundle contains the cumulative English LaTeX source for SGA 4 proper,
Exposés I–XIX including Exposé V bis. It excludes SGA 4½.

The controlling French text is the frozen Orgogozo TeX snapshot at commit
`71766d9`. The archive SHA-256 is
`DA2D939D3BD66B03E7BEFF4353550F7A27982847AE4F798D0872F1DB5D64C7DC`.

## Build

XeLaTeX is required because the included Xy-pic material is not rendered
correctly by the LuaLaTeX compatibility route used during diagnosis.

From `source/tomes`, run three times:

```text
xelatex -interaction=nonstopmode -halt-on-error SGA4_English_translation_workpass.tex
```

The R8 reader is a no-overwrite reader-hygiene successor. It preserves the
mathematics and source-era `N.D.E.` notes while keeping project-production
apparatus only in the editable source. See `READER_HYGIENE_R8.md`.

The release manifest generated alongside the public package records the exact
reader page count and source hashes. The terminal Canon disposition contains
1,604 accepted source-error records, no HOLD records, and 13 REJECT records.
Every accepted reading is integrated into corrected/current sources or bound
by a superseding implementation receipt; rejected readings remain preserved
outside the current branch.

The Spanish companion is maintained by its separate keeper and is linked
through the existing concept DOI
`https://doi.org/10.5281/zenodo.21923955`; it is not a separate Canon source
or a second English/French progress tranche.

## Rights and status

Read `RIGHTS_AND_PROVENANCE.md` before reuse. No license grant is asserted for
the underlying French text, the English translation, or third-party TeX
support files. This is a source-controlled working edition, not a claim of a
new critical edition.

The source preserves 19 inherited `XXX` strings only inside TeX comments.
None appears in the rendered PDF. Their exact disposition is included in the
separate QA evidence bundle.
