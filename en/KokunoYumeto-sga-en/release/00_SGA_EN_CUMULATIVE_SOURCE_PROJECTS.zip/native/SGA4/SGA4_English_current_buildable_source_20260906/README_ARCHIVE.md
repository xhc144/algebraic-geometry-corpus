# SGA4 English current buildable source - 2026-09-06

This dated successor contains exactly 300 frozen source files.
Driver: source/tomes/SGA4_English_translation_workpass.tex; engine: XeLaTeX.
Compile from source/tomes with a normal TeX installation. The recorded root build
used one serialized bounded process tree across all passes and deterministic replay.
The exact source tree, build and QA hashes are bound in SOURCE_REFRESH_RECEIPT.json.
Inherited rights/provenance documents remain byte-identical. Generated PDFs,
auxiliaries, private absolute paths and credentials are excluded.
BUILDABLE_CLOSURE_SHA256.tsv records every other member.
