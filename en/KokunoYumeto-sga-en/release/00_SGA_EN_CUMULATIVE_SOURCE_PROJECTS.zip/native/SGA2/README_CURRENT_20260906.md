# SGA2 English current buildable source - 2026-09-06

Current source: the seventeen files listed in CURRENT_SOURCE_SHA256.tsv.
Driver: active_source/SGA2_English_Full_Reader.tex; engine: pdfLaTeX.
Compile in active_source using a normal TeX installation. The recorded build
used a serialized bounded process tree and byte-identical deterministic replay.
CURRENT_SOURCE_REFRESH.json binds the accepted PDF, source, build and QA.
All inherited evidence, reference tables, release controls and logs are
historical provenance of the older public reader; they are not current QA.
Their member bodies are retained exactly. SOURCE_BUNDLE_SHA256.csv is current.
