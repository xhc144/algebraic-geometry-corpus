# Seminar in Algebraic Geometry - editable English edition

This package contains the complete editable native source projects for the nine
volume PDFs accompanying the linked 4,211-page English reader. It retains the
inherited classes, styles, macros, bibliography, diagrams, licenses and build
instructions. Original authors and redactors are credited in the volume sources.

The 25 September 2026 revision repairs SGA 1's English `Spec` operator macro.
The repair and cumulative assembly were produced by OpenAI Codex - GPT-6 Astra,
Ultra effort. Earlier translation attribution remains in the inherited records.
This AI-assisted edition is not independently human-certified.

## Reading, editing and rebuilding

1. `release/00_SGA_EN_CUMULATIVE_LINKED_READER.tex` contains all nine complete
   LaTeX documents in order, not merely links or input directives. Their native
   preambles and document classes remain separate. It is a reading/editing
   collection, not a single TeX compilation unit. Run
   `python split_cumulative_tex.py release/00_SGA_EN_CUMULATIVE_LINKED_READER.tex split`
   to recover the nine directly downloadable standalone texts exactly.
2. `native/SGA1` through `native/SGA7II` preserve the modular projects. Compile
   from the directory containing each project's master, following its inherited
   README and engine requirements. These native projects, not the flattened
   reading copies, control exact pagination. Styles and dynamic diagram inputs
   required by the direct reading copies are supplied in the native directories.
3. For SGA 1, the native master is `SGA1_English_source_sync_workpass.tex`.
   Three pdfLaTeX passes were used with `SOURCE_DATE_EPOCH=1790294400`,
   `FORCE_SOURCE_DATE=1`, `TZ=UTC`; two independent native builds were
   byte-identical. The complete flattened SGA 1 text also compiles, but its
   paragraph boundaries reflow pages 78-81. Use the native project for exact
   reproduction of the released PDF, not that flattened reading copy.
4. The cumulative PDF is assembled from the nine volume PDFs without changing
   their page streams or page geometry. Download them into `release/` with their
   published filenames. `CUMULATIVE_INPUTS.json` gives their exact SHA-256 pins.
   Install `pypdf==6.10.0` and `reportlab==4.4.9` with Python 3.12, then run
   `python cumulative_reconstruction/rebuild_sga1_20260925.py rebuilt.pdf`.
   The script verifies page streams, geometry, link targets and outline structure.
5. On the original Windows workspace, all TeX runs hold the machine-wide mutex
   `Global\InterlanguageTeXSlotV1` and use a 3,221,225,472-byte captured-tree cap.
   The guarded SGA 1 build scripts and receipts are included under `validation/`.

All eight other volume PDF and native source contents are inherited unchanged.
Only three files in the public SGA 1 native tree change. This release does not
claim to include every separately pending Canon correction.

English edition: https://doi.org/10.5281/zenodo.21925497

Original-language Canon: https://doi.org/10.5281/zenodo.20410947

GitHub: https://github.com/KokunoYumeto/sga-en

The PDF is the reading preview. The complete direct cumulative LaTeX and this
full source ZIP are primary deliverables, immediately after it in the downloads.
