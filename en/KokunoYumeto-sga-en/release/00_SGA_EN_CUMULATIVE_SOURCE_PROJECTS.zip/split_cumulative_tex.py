"""Split the complete cumulative editable text into its nine native documents."""
from pathlib import Path
import re,sys
p=Path(sys.argv[1]);out=Path(sys.argv[2]);out.mkdir(parents=True,exist_ok=True)
text=p.read_bytes();matches=list(re.finditer(rb'(?m)^% SGA-CUMULATIVE-BEGIN ([^\r\n]+)\n',text))
assert len(matches)==9,'Expected all nine volume documents'
for m in matches:
 name=m.group(1).decode('ascii');assert Path(name).name==name
 end=text.index(b'\n% SGA-CUMULATIVE-END '+m.group(1)+b'\n',m.end())
 body=text[m.end():end];dest=out/name
 if dest.exists():assert dest.read_bytes()==body,name
 else:dest.write_bytes(body)
 print(name)
