"""Reproduce the cumulative reader from nine pinned PDFs; no TeX or network."""
from pathlib import Path
from io import BytesIO
import ctypes, hashlib, importlib.util, json, logging, os, sys
from reportlab.pdfgen import canvas
from reportlab.lib.pagesizes import A4
import consumer_pdf_sga2 as c

def memory_guard():
    if os.name!='nt':return None
    from ctypes import wintypes as w
    size=ctypes.c_size_t;u64=ctypes.c_ulonglong
    class BASIC(ctypes.Structure):
        _fields_=[('process_time',ctypes.c_longlong),('job_time',ctypes.c_longlong),
                  ('flags',w.DWORD),('min_working_set',size),('max_working_set',size),
                  ('active_processes',w.DWORD),('affinity',size),('priority',w.DWORD),('scheduling',w.DWORD)]
    class IO(ctypes.Structure):_fields_=[(n,u64) for n in ['read_ops','write_ops','other_ops','read_bytes','write_bytes','other_bytes']]
    class EXT(ctypes.Structure):
        _fields_=[('basic',BASIC),('io',IO),('process_limit',size),('job_limit',size),('peak_process',size),('peak_job',size)]
    dll=ctypes.WinDLL('kernel32',use_last_error=True)
    dll.CreateJobObjectW.argtypes=[ctypes.c_void_p,w.LPCWSTR];dll.CreateJobObjectW.restype=w.HANDLE
    dll.SetInformationJobObject.argtypes=[w.HANDLE,ctypes.c_int,ctypes.c_void_p,w.DWORD];dll.SetInformationJobObject.restype=w.BOOL
    dll.QueryInformationJobObject.argtypes=[w.HANDLE,ctypes.c_int,ctypes.c_void_p,w.DWORD,ctypes.c_void_p];dll.QueryInformationJobObject.restype=w.BOOL
    dll.AssignProcessToJobObject.argtypes=[w.HANDLE,w.HANDLE];dll.AssignProcessToJobObject.restype=w.BOOL
    dll.GetCurrentProcess.restype=w.HANDLE
    job=dll.CreateJobObjectW(None,None)
    if not job:raise ctypes.WinError(ctypes.get_last_error())
    ext=EXT();ext.basic.flags=0x2200;ext.job_limit=3221225472
    if not dll.SetInformationJobObject(job,9,ctypes.byref(ext),ctypes.sizeof(ext)):raise ctypes.WinError(ctypes.get_last_error())
    if not dll.AssignProcessToJobObject(job,dll.GetCurrentProcess()):raise ctypes.WinError(ctypes.get_last_error())
    def query():
        observed=EXT()
        if not dll.QueryInformationJobObject(job,9,ctypes.byref(observed),ctypes.sizeof(observed),None):raise ctypes.WinError(ctypes.get_last_error())
        assert observed.job_limit==3221225472 and observed.basic.flags==0x2200
        return dict(limit_bytes=observed.job_limit,peak_job_bytes=observed.peak_job,
                    mechanism='Windows Job Object, no breakaway, kill on process exit',no_tex_process=True)
    query()
    # Keep the handle alive until process exit; closing it now would kill this process.
    return query

def front(records,date,tree):
    b=BytesIO();p=canvas.Canvas(b,pagesize=A4,invariant=1,pageCompression=1);w,h=A4
    p.setTitle('Seminar in Algebraic Geometry (SGA) - Cumulative English Edition')
    p.setAuthor('Alexander Grothendieck and the authors credited in each volume')
    p.setFont('Helvetica',21);p.drawCentredString(w/2,h-125,'Seminar in Algebraic Geometry')
    p.setFont('Helvetica-Bold',23);p.drawCentredString(w/2,h-170,'Cumulative English Edition')
    p.setFont('Helvetica',17);p.drawCentredString(w/2,h-205,'SGA 1 through SGA 7')
    lines=['Algebraic fundamental groups, local and etale cohomology,',
           'group schemes, intersection theory and monodromy.', '',
           'The original authors, directors and redactors are credited in each volume.',
           'This AI-assisted translation is a working scholarly edition;',
           'it is not an independently human-certified edition.', '',
           'Read a volume using the linked contents on the following page.',
           'Complete editable LaTeX and native source projects accompany this reader.', '',
           'English edition: doi:10.5281/zenodo.21925497',
           'Original-language Canon: doi:10.5281/zenodo.20410947']
    p.setFont('Helvetica',10)
    for i,t in enumerate(lines):p.drawCentredString(w/2,h-280-20*i,t)
    p.setFont('Helvetica',8)
    p.drawCentredString(w/2,135,'SGA 7 I includes Exposes I, II, VI, VII, VIII and IX; inherited coverage is retained.')
    p.drawCentredString(w/2,120,'Correction integration and assembly: OpenAI Codex - GPT-6 Astra, Ultra effort.')
    p.drawCentredString(w/2,105,'Earlier translation provenance is retained in the volume sources and edition records.')
    p.drawCentredString(w/2,80,'Edition date: '+date)
    p.showPage();p.setFont('Helvetica-Bold',24);p.drawCentredString(w/2,h-72,'Contents')
    p.setFont('Helvetica',10);p.drawCentredString(w/2,h-101,'Choose a volume. Its chapter bookmarks and internal links are retained.')
    y=h-160;start=3
    for r in records:
        end=start+r['pages']-1;p.setFont('Helvetica-Bold',12);p.drawString(72,y,r['title'])
        p.setFont('Helvetica',11);p.drawRightString(w-72,y,f'{start}-{end}')
        p.linkURL('sga-global:'+r['prefix'],(68,y-4,w-68,y+15),relative=0,thickness=0)
        start=end+1;y-=42
    p.setFont('Helvetica',10);p.drawCentredString(w/2,130,f'{start-1:,} pages, including these two navigation pages.')
    p.setFont('Helvetica',9);p.drawCentredString(w/2,99,'English edition and editable sources: doi:10.5281/zenodo.21925497')
    p.linkURL('https://doi.org/10.5281/zenodo.21925497',(55,92,w-55,111),relative=0,thickness=0)
    p.save();return b.getvalue()

def load(name,path):
    spec=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m
def main():
    assert len(sys.argv)==2 and Path(sys.argv[1]).name==sys.argv[1]
    query=memory_guard()
    root=Path(__file__).resolve().parent.parent
    logging.getLogger('pypdf').addHandler(logging.FileHandler(root/(sys.argv[1]+'.assembly.log'),encoding='utf-8'))
    logging.getLogger('pypdf').propagate=False
    records=json.loads((root/'CUMULATIVE_INPUTS.json').read_bytes())
    for r in records:
        path=root/'release'/r['name'];data=path.read_bytes()
        assert len(data)==r['bytes'] and hashlib.sha256(data).hexdigest().upper()==r['sha256']
        r['path']=str(path)
    c.frontmatter_bytes=front
    helper=load('helper',Path(__file__).parent/'build_prefixed_pdf_with_frontmatter_20260823.py')
    audit=load('auditor',Path(__file__).parent/'build_global_english_reader_terminal_20260823.py')
    result=c.build_cumulative(root/'release'/sys.argv[1],records,'3 October 2026','',helper,audit)
    if query:result['memory_guard']=query()
    import pypdf,reportlab
    result['runtime']=dict(python=sys.version,pypdf=pypdf.__version__,reportlab=reportlab.Version)
    with (root/(sys.argv[1]+'.QA.json')).open('x',encoding='utf-8',newline='\n') as f:json.dump(result,f,indent=2);f.write('\n')
if __name__=='__main__':main()
