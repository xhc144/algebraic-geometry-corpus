"""Build a cumulative PDF with clean LaTeX front matter and namespaced inputs.

Usage:
  python tools/build_prefixed_pdf_with_frontmatter.py OUTPUT.pdf \
      --frontmatter FRONTMATTER.pdf PREFIX TITLE INPUT.pdf [...]

The front matter is appended first and must contain links to stable aliases of
the form ``SGA-GLOBAL::<PREFIX>``.  Each standalone reader is then appended
whole.  Page content, page annotations, and outlines are cloned by pypdf.
Named destinations and named GoTo actions are prefixed before cloning so
identical names in different volumes cannot silently misroute.  A stable alias
is created at the first page of every reader so the visible global contents and
PDF bookmark hierarchy share the same destination.
"""

from __future__ import annotations

import json
import hashlib
import sys
from pathlib import Path
from typing import Any

from pypdf import PdfReader, PdfWriter
from pypdf.generic import NameObject, TextStringObject


def _named_key(value: Any, known: set[str]) -> str | None:
    if not isinstance(value, str):
        return None
    raw = str(value)
    if raw in known:
        return raw
    if raw.startswith("/") and raw[1:] in known:
        return raw[1:]
    return None


def namespace_reader(reader: PdfReader, prefix: str) -> dict[str, Any]:
    original = reader.named_destinations
    known = set(original)
    renamed: dict[str, Any] = {}
    expected_local_pages: dict[str, int] = {}

    for old_name, destination in original.items():
        new_name = f"{prefix}::{old_name}"
        expected_local_pages[new_name] = reader.get_destination_page_number(destination)
        destination[NameObject("/Title")] = TextStringObject(new_name)
        renamed[new_name] = destination

    # PdfWriter.append asks the reader for this property immediately before
    # importing destinations.  An instance function is intentional here: it
    # returns the already resolved, uniquely renamed destination set.
    reader._get_named_destinations = lambda *args, **kwargs: renamed  # type: ignore[method-assign]

    renamed_actions = 0
    unresolved_named_actions: list[str] = []
    link_annotations = 0

    for page in reader.pages:
        for annot_ref in page.get("/Annots") or []:
            annot = annot_ref.get_object()
            if annot.get("/Subtype") != "/Link":
                continue
            link_annotations += 1

            action = annot.get("/A")
            container = None
            key = None
            value = None
            if action and action.get("/S") == "/GoTo":
                container, key, value = action, NameObject("/D"), action.get("/D")
            elif annot.get("/Dest") is not None:
                container, key, value = annot, NameObject("/Dest"), annot.get("/Dest")

            old_name = _named_key(value, known)
            if old_name is not None and container is not None and key is not None:
                container[key] = TextStringObject(f"{prefix}::{old_name}")
                renamed_actions += 1
            elif isinstance(value, str):
                unresolved_named_actions.append(str(value))

    return {
        "prefix": prefix,
        "pages": len(reader.pages),
        "named_destinations": len(renamed),
        "link_annotations": link_annotations,
        "renamed_named_actions": renamed_actions,
        "unresolved_named_actions": sorted(set(unresolved_named_actions)),
        "expected_local_pages": expected_local_pages,
    }


def rewrite_frontmatter_actions(pages: Any) -> dict[str, Any]:
    """Convert LaTeX URI placeholders into stable internal GoTo actions."""

    rewritten = 0
    other_links = 0
    aliases: list[str] = []
    for page in pages:
        for annot_ref in page.get("/Annots") or []:
            annot = annot_ref.get_object()
            if annot.get("/Subtype") != "/Link":
                continue
            action = annot.get("/A")
            if not action or action.get("/S") != "/URI":
                other_links += 1
                continue
            uri = str(action.get("/URI") or "")
            if not uri.startswith("sga-global:"):
                other_links += 1
                continue
            prefix = uri.removeprefix("sga-global:")
            alias = f"SGA-GLOBAL::{prefix}"
            action[NameObject("/S")] = NameObject("/GoTo")
            action[NameObject("/D")] = TextStringObject(alias)
            del action[NameObject("/URI")]
            aliases.append(alias)
            rewritten += 1
    return {
        "rewritten_volume_links": rewritten,
        "other_link_annotations": other_links,
        "aliases": aliases,
    }


def extract_outline(reader: PdfReader) -> list[dict[str, Any]]:
    """Convert pypdf's alternating item/list outline form to a plain tree."""

    def walk(items: list[Any]) -> list[dict[str, Any]]:
        result: list[dict[str, Any]] = []
        previous: dict[str, Any] | None = None
        for item in items:
            if isinstance(item, list):
                if previous is not None:
                    previous["children"] = walk(item)
                continue
            title = str(getattr(item, "title", ""))
            try:
                page = reader.get_destination_page_number(item)
            except Exception:
                page = -1
            previous = {"title": title, "page": page, "children": []}
            result.append(previous)
        return result

    return walk(reader.outline)


def count_outline(items: list[dict[str, Any]]) -> int:
    return sum(1 + count_outline(item["children"]) for item in items)


def add_outline_tree(
    writer: PdfWriter,
    items: list[dict[str, Any]],
    page_offset: int,
    parent: Any,
) -> int:
    added = 0
    for item in items:
        local_page = int(item["page"])
        if local_page < 0:
            continue
        node = writer.add_outline_item(
            str(item["title"]), page_offset + local_page, parent=parent
        )
        added += 1
        added += add_outline_tree(
            writer, item["children"], page_offset=page_offset, parent=node
        )
    return added


def main() -> int:
    if len(sys.argv) < 8 or sys.argv[2] != "--frontmatter" or (len(sys.argv) - 4) % 3:
        print(
            "usage: build_prefixed_pdf_with_frontmatter.py OUTPUT.pdf "
            "--frontmatter FRONTMATTER.pdf PREFIX TITLE INPUT.pdf [...]",
            file=sys.stderr,
        )
        return 2

    output = Path(sys.argv[1])
    frontmatter_path = Path(sys.argv[3])
    triples = [sys.argv[i : i + 3] for i in range(4, len(sys.argv), 3)]
    writer = PdfWriter()
    writer.add_metadata(
        {
            "/Title": "SGA 1-7.2 - English Reader",
            "/Author": "SGA authors and redactors",
            "/Subject": "English translations of SGA 1 through SGA 7 II",
            "/Keywords": "SGA, algebraic geometry, English translation",
        }
    )
    records: list[dict[str, Any]] = []
    frontmatter_reader = PdfReader(frontmatter_path)
    frontmatter_named_destinations = len(frontmatter_reader.named_destinations)
    writer.append(frontmatter_reader, import_outline=False)
    frontmatter_pages = len(frontmatter_reader.pages)
    if frontmatter_pages != 2:
        raise ValueError(
            f"front matter must be exactly 2 pages; observed {frontmatter_pages}"
        )
    writer.add_outline_item("Global contents", 1)
    page_offset = frontmatter_pages

    for prefix, title, input_name in triples:
        reader = PdfReader(input_name)
        outline = extract_outline(reader)
        record = namespace_reader(reader, prefix)
        record["title"] = title
        record["input"] = str(Path(input_name))
        record["page_offset"] = page_offset
        record["source_outline_items"] = count_outline(outline)
        writer.append(reader, import_outline=False)
        stable_alias = f"SGA-GLOBAL::{prefix}"
        writer.add_named_destination(stable_alias, page_offset)
        volume_node = writer.add_outline_item(title, page_offset)
        record["stable_volume_alias"] = stable_alias
        record["imported_outline_items"] = add_outline_tree(
            writer, outline, page_offset=page_offset, parent=volume_node
        )
        page_offset += record["pages"]
        records.append(record)

    # URI annotations survive an unresolved import.  Rewrite them only after
    # every final stable alias has been added to the writer.
    frontmatter_actions = rewrite_frontmatter_actions(
        writer.pages[:frontmatter_pages]
    )
    expected_aliases = [f"SGA-GLOBAL::{prefix}" for prefix, _, _ in triples]
    actual_aliases: list[str] = []
    for alias in frontmatter_actions["aliases"]:
        if alias not in actual_aliases:
            actual_aliases.append(alias)
    if actual_aliases != expected_aliases:
        raise ValueError(
            "front-matter link aliases differ from the ordered input prefixes: "
            f"{actual_aliases} != {expected_aliases}"
        )

    output.parent.mkdir(parents=True, exist_ok=True)
    with output.open("wb") as stream:
        writer.write(stream)

    result = {
        "schema": "sga-global-prefixed-pdf-with-frontmatter-build-v2",
        "output": str(output),
        "pages": page_offset,
        "frontmatter": {
            "path": str(frontmatter_path),
            "pages": frontmatter_pages,
            "named_destinations": frontmatter_named_destinations,
            "bytes": frontmatter_path.stat().st_size,
            "sha256": hashlib.sha256(frontmatter_path.read_bytes()).hexdigest().upper(),
            "actions": frontmatter_actions,
        },
        "inputs": records,
    }
    evidence_path = output.with_name(f"{output.stem}_build.json")
    evidence_path.write_text(
        json.dumps(result, ensure_ascii=False, indent=2, sort_keys=True) + "\n",
        encoding="utf-8",
    )
    print(
        json.dumps(
            {
                "output": str(output),
                "build_evidence": str(evidence_path),
                "pages": page_offset,
                "inputs": len(records),
                "named_destinations": frontmatter_named_destinations
                + len(records)
                + sum(r["named_destinations"] for r in records),
                "link_annotations": sum(r["link_annotations"] for r in records),
                "outline_items": 1
                + len(records)
                + sum(r["imported_outline_items"] for r in records),
                "unresolved_named_actions": sum(
                    len(r["unresolved_named_actions"]) for r in records
                ),
            },
            ensure_ascii=False,
            sort_keys=True,
        )
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
