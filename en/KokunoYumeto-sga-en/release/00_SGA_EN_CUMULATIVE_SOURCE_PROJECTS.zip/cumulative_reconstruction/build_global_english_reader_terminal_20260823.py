from __future__ import annotations

import hashlib
import importlib.util
import json
import shutil
import sys
from collections import Counter
from pathlib import Path
from typing import Any

from pypdf import PdfReader
from pypdf.generic import ArrayObject, DictionaryObject, IndirectObject, NameObject, TextStringObject


WORK = Path(
    r"${WORKSPACE}\00_governance\work"
    r"\global_transcript_reconciliation_20260823"
)
BASE_SCRIPT = WORK / "build_global_english_reader_final_20260823.py"
OUT_ROOT = WORK / "global_english_reader_terminal2_20260823"
SGA3_PDF = (
    WORK
    / "sga3_current_overlay_20260823"
    / "SGA3_English_Complete_Native_ReferenceV2_current_20260823.pdf"
)
SGA4_PDF = (
    WORK
    / "build_sga4_r8_public_hold_resolution_en_20260823"
    / "SGA4_English_translation_workpass.pdf"
)
SGA6_PDF = (
    WORK
    / "build_sga6_hold72_en_20260823"
    / "02f_SGA6_English_Master.pdf"
)
SGA7I_PDF = (
    WORK
    / "build_sga7i_source_first_hold_resolution_en_replay_20260823"
    / "SGA7_I_English_source_first_workpass.pdf"
)


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest().upper()


def resolve(value: Any) -> Any:
    return value.get_object() if isinstance(value, IndirectObject) else value


def destination_name(value: Any) -> str | None:
    value = resolve(value)
    if isinstance(value, (TextStringObject, NameObject, str)):
        text = str(value)
        return text[1:] if isinstance(value, NameObject) and text.startswith("/") else text
    return None


def audit_actions(reader: PdfReader) -> dict[str, Any]:
    named = set(reader.named_destinations)
    actions = Counter()
    named_goto_targets: list[str] = []
    unresolved: list[str] = []
    unsafe: list[dict[str, Any]] = []
    annotations = 0

    for page_number, page in enumerate(reader.pages, start=1):
        annots = resolve(page.get("/Annots"))
        if not isinstance(annots, ArrayObject):
            continue
        for raw_annot in annots:
            annot = resolve(raw_annot)
            if not isinstance(annot, DictionaryObject):
                continue
            annotations += 1
            direct_dest = annot.get("/Dest")
            if direct_dest is not None:
                name = destination_name(direct_dest)
                if name is not None:
                    actions["direct_named_dest"] += 1
                    named_goto_targets.append(name)
                    if name not in named:
                        unresolved.append(name)
                else:
                    actions["direct_explicit_dest"] += 1
            action = resolve(annot.get("/A"))
            if not isinstance(action, DictionaryObject):
                continue
            subtype = str(action.get("/S", "<none>"))
            actions[subtype] += 1
            if subtype == "/GoTo":
                name = destination_name(action.get("/D"))
                if name is not None:
                    named_goto_targets.append(name)
                    if name not in named:
                        unresolved.append(name)
            elif subtype in {"/GoToR", "/Launch", "/JavaScript", "/SubmitForm", "/ImportData"}:
                unsafe.append({"page": page_number, "subtype": subtype})

    return {
        "annotations": annotations,
        "action_subtypes": dict(sorted(actions.items())),
        "named_goto_actions": len(named_goto_targets),
        "unique_named_goto_targets": len(set(named_goto_targets)),
        "unresolved_named_goto_actions": len(unresolved),
        "unresolved_named_goto_names": sorted(set(unresolved)),
        "unsafe_external_or_executable_actions": unsafe,
    }


def main() -> int:
    if OUT_ROOT.exists():
        raise RuntimeError(f"refusing to overwrite terminal global reader root: {OUT_ROOT}")
    for path in (SGA3_PDF, SGA4_PDF, SGA6_PDF, SGA7I_PDF):
        if not path.is_file():
            raise RuntimeError(f"required terminal reader input is missing: {path}")

    spec = importlib.util.spec_from_file_location("sga_global_reader_base", BASE_SCRIPT)
    if spec is None or spec.loader is None:
        raise RuntimeError("could not load verified global-reader builder")
    module = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = module
    spec.loader.exec_module(module)
    module.OUT_ROOT = OUT_ROOT
    module.SGA3_PDF = SGA3_PDF
    module.SGA4_PDF = SGA4_PDF
    module.SGA6_PDF = SGA6_PDF
    module.SGA7I_PDF = SGA7I_PDF
    module.main()

    generated = OUT_ROOT / "SGA_1_7II_English_Global_Reader_20260823.pdf"
    terminal_pdf = OUT_ROOT / "SGA_1_7II_English_Global_Reader_terminal_20260823.pdf"
    shutil.copy2(generated, terminal_pdf)
    reader = PdfReader(str(terminal_pdf))
    action_audit = audit_actions(reader)
    named = reader.named_destinations
    required_aliases = [
        "SGA-GLOBAL::SGA1",
        "SGA-GLOBAL::SGA2",
        "SGA-GLOBAL::SGA3",
        "SGA-GLOBAL::SGA4",
        "SGA-GLOBAL::SGA4H",
        "SGA-GLOBAL::SGA5",
        "SGA-GLOBAL::SGA6",
        "SGA-GLOBAL::SGA7I",
        "SGA-GLOBAL::SGA7II",
    ]
    missing_aliases = [name for name in required_aliases if name not in named]
    if len(reader.pages) != 4204:
        raise RuntimeError(f"terminal global page count {len(reader.pages)} != 4204")
    if missing_aliases:
        raise RuntimeError(f"terminal global reader missing aliases: {missing_aliases}")
    if action_audit["unresolved_named_goto_actions"]:
        raise RuntimeError(
            "terminal global reader has unresolved named GoTo actions: "
            + json.dumps(action_audit["unresolved_named_goto_names"][:50])
        )
    if action_audit["unsafe_external_or_executable_actions"]:
        raise RuntimeError("terminal global reader has unsafe external/executable actions")

    base_receipt = OUT_ROOT / "GLOBAL_READER_BUILD_RECEIPT_20260823.json"
    receipt = {
        "schema": "sga-global-english-reader-terminal-build/v1",
        "status": "PASS_DETERMINISTIC_STRUCTURAL_ACTION_GRAPH",
        "output": {
            "path": str(terminal_pdf),
            "bytes": terminal_pdf.stat().st_size,
            "sha256": sha256_file(terminal_pdf),
            "pages": len(reader.pages),
            "named_destinations": len(named),
        },
        "base_build_receipt": {
            "path": str(base_receipt),
            "bytes": base_receipt.stat().st_size,
            "sha256": sha256_file(base_receipt),
        },
        "terminal_inputs": {
            "sga3": {"path": str(SGA3_PDF), "bytes": SGA3_PDF.stat().st_size, "sha256": sha256_file(SGA3_PDF)},
            "sga4": {"path": str(SGA4_PDF), "bytes": SGA4_PDF.stat().st_size, "sha256": sha256_file(SGA4_PDF)},
            "sga6": {"path": str(SGA6_PDF), "bytes": SGA6_PDF.stat().st_size, "sha256": sha256_file(SGA6_PDF)},
            "sga7i": {"path": str(SGA7I_PDF), "bytes": SGA7I_PDF.stat().st_size, "sha256": sha256_file(SGA7I_PDF)},
        },
        "required_volume_aliases": required_aliases,
        "missing_volume_aliases": missing_aliases,
        "action_audit": action_audit,
        "canon_counts": {"accepted": 1604, "held": 0, "rejected": 13},
        "spanish": {"mode": "companion DOI link only", "doi": "10.5281/zenodo.21923955", "embedded_files": 0},
        "visual_qa": "PENDING_SEPARATE_RECEIPT",
        "publication_mutation": False,
    }
    receipt_path = WORK / "GLOBAL_READER_BUILD_RECEIPT_FINAL_20260823.json"
    receipt_path.write_text(
        json.dumps(receipt, ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
        newline="\n",
    )
    print(json.dumps(receipt, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
