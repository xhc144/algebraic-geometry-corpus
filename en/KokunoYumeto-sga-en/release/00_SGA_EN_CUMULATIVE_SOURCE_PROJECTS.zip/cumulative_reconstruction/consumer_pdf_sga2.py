"""SGA-only cumulative assembly, called only by the root execution adapter.

No execution on import. The pinned historical namespace/action functions are
passed in, not fetched. Rich outline operands supplement their title/page tree.
"""
from pathlib import Path
from io import BytesIO
import hashlib, json, time
from pypdf import PdfReader, PdfWriter
from pypdf.generic import ArrayObject, DictionaryObject, IndirectObject, NullObject, Fit, NameObject, NumberObject
from reportlab.pdfgen import canvas
from reportlab.lib.pagesizes import A4

if not __debug__:
    raise RuntimeError('Run without Python optimization; fail-closed checks are mandatory.')

ORDER=['SGA1','SGA2','SGA3','SGA4','SGA4H','SGA5','SGA6','SGA7I','SGA7II']

def sha(data): return hashlib.sha256(data).hexdigest().upper()
def deref(value): return value.get_object() if isinstance(value,IndirectObject) else value
def named_index(reader):
    # PdfReader.named_destinations reparses the full tree on each property read.
    # Resolve once per reader state; explicitly invalidate after namespacing.
    index=getattr(reader,'_sga_named_index',None)
    if index is None:
        index=reader.named_destinations
        reader._sga_named_index=index
    return index
def scalar(value):
    value=deref(value)
    if value is None or isinstance(value,NullObject): return None
    if isinstance(value,(list,tuple,ArrayObject)): return [scalar(v) for v in value]
    if isinstance(value,(int,float)): return float(value)
    if isinstance(value,str): return str(value)
    raise ValueError('Unsupported scalar PDF value type: '+type(value).__name__)

def safety(reader):
    """Reject unhandled executable/event features; never silently discard them."""
    root=reader.trailer['/Root']
    assert not root.get('/AA'), 'Catalog additional actions unsupported'
    assert not root.get('/AcroForm'), 'Interactive form unsupported'
    names=deref(root.get('/Names')) or {}
    assert not names.get('/JavaScript') and not names.get('/EmbeddedFiles')
    opening=deref(root.get('/OpenAction'))
    if isinstance(opening,DictionaryObject):
        assert opening.get('/S')=='/GoTo' and not opening.get('/Next')
        destination(reader,opening['/D'])
    elif opening is not None:
        assert isinstance(opening,ArrayObject), 'Unsupported initial-view action'
        destination(reader,opening)
    for page in reader.pages:
        assert not page.get('/AA'), 'Page additional actions unsupported'
        for raw in page.get('/Annots') or []:
            a=deref(raw)
            assert a.get('/Subtype')=='/Link', 'Non-link annotation unsupported'
            assert not a.get('/AA') and not a.get('/AP'), 'Annotation event/appearance unsupported'
            from pypdf.generic import NameObject
            if '/Dest' in a:a[NameObject('/Dest')]=deref(a['/Dest'])
            action=deref(a.get('/A'))
            if action:
                assert not action.get('/Next'), 'Chained actions unsupported'
                assert action.get('/S') in ('/GoTo','/URI'), 'External/executable action unsupported'
                # Historical helper expects a directly usable action dictionary.
                assert isinstance(action,DictionaryObject)
                a[NameObject('/A')]=action
                if action.get('/S')=='/GoTo':action[NameObject('/D')]=deref(action['/D'])

def page_index(reader,value):
    value=deref(value)
    if isinstance(value,int): return int(value)
    ref=getattr(value,'indirect_reference',None)
    assert ref is not None,'Explicit destination is not a page'
    mapping=getattr(reader,'_sga_page_index',None)
    if mapping is None:
        mapping={(p.indirect_reference.idnum,p.indirect_reference.generation):i for i,p in enumerate(reader.pages)}
        reader._sga_page_index=mapping
    return mapping[(ref.idnum,ref.generation)]

def destination(reader,value,prefix='',offset=0):
    value=deref(value)
    if isinstance(value,str):
        name=str(value)
        names=named_index(reader)
        if name not in names and name.startswith('/'):
            name=name[1:]
        assert name in names, 'Unresolved named destination: '+name
        d=names[name]
        return {'name':prefix+name,'page':reader.get_destination_page_number(d)+offset,'fit':scalar(d.dest_array[1:])}
    assert isinstance(value,ArrayObject),'Unsupported destination'
    return {'explicit':True,'page':page_index(reader,value[0])+offset,'fit':scalar(value[1:])}

def annotation_signature(reader,page,prefix='',offset=0):
    rows=[]
    for raw in page.get('/Annots') or []:
        a=deref(raw); row={}
        for k in ('/Subtype','/Rect','/Border','/C','/H','/F','/QuadPoints','/Contents'):
            if k in a: row[k]=scalar(a[k])
        if '/Dest' in a: row['dest']=destination(reader,a['/Dest'],prefix,offset)
        action=deref(a.get('/A'))
        if action:
            if action['/S']=='/GoTo': row['action']=destination(reader,action['/D'],prefix,offset)
            else: row['uri']=str(action['/URI']); row['is_map']=bool(action.get('/IsMap',False))
        rows.append(row)
    return rows

def geometry(page):
    return {'media':list(map(float,page.mediabox)),'crop':list(map(float,page.cropbox)),
            'trim':list(map(float,page.trimbox)),'bleed':list(map(float,page.bleedbox)),
            'art':list(map(float,page.artbox)),'rotation':int(page.get('/Rotate',0)),
            'user_unit':float(page.get('/UserUnit',1))}

def rich_outline(reader):
    def walk(items):
        rows=[]; prior=None
        for item in items:
            if isinstance(item,list):
                assert prior is not None
                prior['children']=walk(item)
                continue
            number=reader.get_destination_page_number(item)
            assert number>=0,'Unresolved outline destination'
            prior={'title':str(item.title),'page':number,'fit':scalar(item.dest_array[1:]),
                   'flags':int(item.get('/F',0)),'color':scalar(item.get('/C')),
                   'open':int(item.get('/Count',0))>=0,
                   'count':int(item['/Count']) if '/Count' in item else None,'children':[]}
            rows.append(prior)
        return rows
    return walk(reader.outline)

def simple_outline(items):
    return [{'title':r['title'],'page':r['page'],'children':simple_outline(r['children'])} for r in items]

def add_rich_outline(writer,items,offset,parent):
    for r in items:
        node=writer.add_outline_item(r['title'],r['page']+offset,parent=parent,
               color=tuple(r['color']) if r['color'] else None,bold=bool(r['flags']&2),
               italic=bool(r['flags']&1),fit=Fit(r['fit'][0],tuple(r['fit'][1:])),is_open=r['open'])
        add_rich_outline(writer,r['children'],offset,node)
        # pypdf's closed-child insertion does not increment the parent count.
        # Restore the original signed count after recursion: /%is_open% is not
        # serialized, so a closed parent left at zero would reopen on readback.
        if r['count'] is None:
            node.get_object().pop(NameObject('/Count'),None)
        else:
            node.get_object()[NameObject('/Count')]=NumberObject(r['count'])

def visible_outline_count(items):
    # A closed child itself remains visible; only its descendants are hidden.
    return sum(1+(visible_outline_count(r['children']) if r['open'] else 0) for r in items)

def offset_outline(items,offset):
    return [{**r,'page':r['page']+offset,'children':offset_outline(r['children'],offset)} for r in items]

def frontmatter_bytes(records,release_date,source_tree):
    """Exactly two current pages, deterministic ReportLab; no TeX subprocess."""
    buf=BytesIO(); c=canvas.Canvas(buf,pagesize=A4,invariant=1,pageCompression=1)
    c.setTitle('SGA English Cumulative Reader - SGA 2 source refresh '+release_date)
    c.setAuthor('SGA authors and redactors')
    w,h=A4
    c.setFont('Helvetica',15); c.drawCentredString(w/2,h-115,'Seminaire de Geometrie Algebrique')
    c.setFont('Helvetica-Bold',28); c.drawCentredString(w/2,h-167,'English Cumulative Reader')
    c.setFont('Helvetica',20); c.drawCentredString(w/2,h-203,'SGA 1 through SGA 7 II')
    c.setFont('Helvetica-Bold',13); c.drawCentredString(w/2,h-290,'SGA 2 source refresh - '+release_date)
    c.setFont('Helvetica',10)
    lines=['This edition replaces the SGA 2 reader from the validated final source snapshot.',
           'The other eight readers, including the latest SGA 4, retain their published bodies.',
           'No claim is made that they include later, unpublished source corrections.',
           'Volume bookmarks and internal links follow each included reader.',
           'The two-page navigation frontmatter is new; no historical canon counts are reused.']
    for i,text in enumerate(lines):c.drawCentredString(w/2,h-340-i*19,text)
    c.setFont('Helvetica',8); c.drawCentredString(w/2,120,'SGA 2 frozen source-tree SHA-256')
    c.setFont('Courier',7); c.drawCentredString(w/2,105,source_tree)
    c.showPage()
    c.setFont('Helvetica-Bold',24);c.drawCentredString(w/2,h-72,'Global Contents')
    c.setFont('Helvetica',10);c.drawCentredString(w/2,h-101,'Select a volume; its complete bookmark hierarchy is retained.')
    y=h-165; start=3
    for r in records:
        end=start+r['pages']-1
        c.setFont('Helvetica-Bold',13);c.drawString(72,y,r['title'])
        c.setFont('Helvetica',12);c.drawRightString(w-72,y,f'pages {start}-{end}')
        c.linkURL('sga-global:'+r['prefix'],(68,y-4,w-68,y+15),relative=0,thickness=0)
        start=end+1;y-=42
    c.setFont('Helvetica',10);c.drawCentredString(w/2,130,f'Total: {start-1} pages, including this two-page navigation frontmatter.')
    c.setFont('Helvetica',9)
    c.drawCentredString(w/2,96,'Published predecessor and continuing English lineage: doi:10.5281/zenodo.21925497')
    c.linkURL('https://doi.org/10.5281/zenodo.21925497',(55,90,w-55,105),relative=0,thickness=0)
    c.save();return buf.getvalue()

def build_cumulative(output,records,release_date,source_tree,helper,auditor):
    started=time.monotonic()
    def progress(stage,**details):
        print(json.dumps({'stage':stage,'elapsed_seconds':round(time.monotonic()-started,3),**details}),flush=True)
    progress('reader_validation_begin')
    assert [r['prefix'] for r in records]==ORDER
    readers=[PdfReader(r['path'],strict=True) for r in records]
    for r,reader in zip(records,readers):
        safety(reader);r['pages']=len(reader.pages)
    progress('reader_validation_complete',input_pages=sum(r['pages'] for r in records))
    front=frontmatter_bytes(records,release_date,source_tree)
    writer=PdfWriter();front_reader=PdfReader(BytesIO(front),strict=True)
    assert len(front_reader.pages)==2
    writer.append(front_reader,import_outline=False)
    from pypdf.generic import NameObject
    writer._root_object[NameObject('/OpenAction')]=ArrayObject([writer.pages[0].indirect_reference,NameObject('/Fit')])
    writer.add_metadata({'/Title':'Seminar in Algebraic Geometry (SGA) - Cumulative English Edition',
                         '/Author':'Alexander Grothendieck; Michel Demazure; Michael Artin; Jean-Louis Verdier; Pierre Deligne; Luc Illusie; Pierre Berthelot; Nicholas M. Katz; see volume credits',
                         '/Subject':'SGA 1-7 in English, with linked volume navigation and complete editable sources'})
    writer.add_outline_item('Global contents',1)
    expected_pages=[];expected_destinations={};expected_outlines=[];offset=2;inputs=[]
    for record,reader in zip(records,readers):
        prefix=record['prefix'];rich=rich_outline(reader)
        progress('source_capture_begin',prefix=prefix,pages=len(reader.pages))
        assert simple_outline(rich)==helper.extract_outline(reader),'Rich outline disagrees with inherited title/page capture'
        for page in reader.pages:
            content=page.get_contents()
            expected_pages.append({'content':sha(content.get_data() if content else b''),'geometry':geometry(page),
                                   'annotations':annotation_signature(reader,page,prefix+'::',offset)})
        for name,d in named_index(reader).items():
            expected_destinations[prefix+'::'+name]={'page':reader.get_destination_page_number(d)+offset,'fit':scalar(d.dest_array[1:])}
        progress('source_capture_complete',prefix=prefix)
        info=helper.namespace_reader(reader,prefix)
        reader.__dict__.pop('_sga_named_index',None)
        assert not info['unresolved_named_actions'],'Inherited namespace helper found unresolved names'
        progress('volume_append_begin',prefix=prefix)
        writer.append(reader,import_outline=False)
        progress('volume_append_complete',prefix=prefix)
        alias='SGA-GLOBAL::'+prefix;writer.add_named_destination(alias,offset)
        parent=writer.add_outline_item(record['title'],offset)
        add_rich_outline(writer,rich,offset,parent)
        parent.get_object()[NameObject('/Count')]=NumberObject(visible_outline_count(rich))
        expected_outlines.append((record['title'],offset,offset_outline(rich,offset)))
        inputs.append({'prefix':prefix,'pages':len(reader.pages),'offset':offset,'named_destinations':len(reader.named_destinations)})
        offset+=len(reader.pages)
    # These ten new top-level nodes are open. Source nodes retain their exact
    # original counts above; only the newly created wrappers need fresh counts.
    writer.get_outline_root()[NameObject('/Count')]=NumberObject(
        1+sum(1+visible_outline_count(children) for _,_,children in expected_outlines))
    front_links=helper.rewrite_frontmatter_actions(writer.pages[:2])
    assert front_links['aliases']==['SGA-GLOBAL::'+p for p in ORDER]
    progress('pdf_write_begin',pages=offset)
    with Path(output).open('xb') as stream:writer.write(stream)
    progress('pdf_write_complete')
    combined=PdfReader(output,strict=True);safety(combined)
    assert len(combined.pages)==offset
    for page,expected in zip(list(combined.pages)[2:],expected_pages):
        content=page.get_contents()
        assert sha(content.get_data() if content else b'')==expected['content'],'Decoded page-content loss'
        assert geometry(page)==expected['geometry'],'Page geometry changed'
        assert annotation_signature(combined,page)==expected['annotations'],'Internal/external annotation destination changed'
    progress('all_page_content_geometry_links_verified')
    names=named_index(combined)
    for name,expected in expected_destinations.items():
        assert name in names and combined.get_destination_page_number(names[name])==expected['page']
        assert scalar(names[name].dest_array[1:])==expected['fit'],'Named destination viewport changed'
    for r in inputs:
        assert combined.get_destination_page_number(names['SGA-GLOBAL::'+r['prefix']])==r['offset']
    # ReportLab creates no extra named destinations; only source names and nine aliases.
    assert set(names)==set(expected_destinations)|{'SGA-GLOBAL::'+p for p in ORDER}
    actual=rich_outline(combined)
    assert len(actual)==10 and actual[0]['title']=='Global contents'
    for got,(title,start,children) in zip(actual[1:],expected_outlines):
        assert got['title']==title and got['page']==start and got['children']==children,'Outline destination/style/open-state changed'
        assert got['count']==visible_outline_count(children),'Volume-wrapper visible-outline count changed'
    assert int(combined.trailer['/Root']['/Outlines']['/Count'])==1+sum(
        1+visible_outline_count(children) for _,_,children in expected_outlines),'Root visible-outline count changed'
    actions=auditor.audit_actions(combined)
    assert actions['unresolved_named_goto_actions']==0 and not actions['unsafe_external_or_executable_actions']
    progress('cumulative_structural_verification_complete',pages=offset,named_destinations=len(names))
    return {'pages':offset,'frontmatter_pages':2,'frontmatter_sha256':sha(front),'inputs':inputs,
            'named_destinations':len(names),'source_page_content_geometry_and_link_parity':True,
            'rich_outline_parity':True,'action_audit':actions,
            'initial_view':'Cumulative frontmatter page1 /Fit; standalone initial-view actions are not nine independent catalog actions.',
            'visual_qa':'ROOT_POST_ASSEMBLY_VISUAL_CHECK_REQUIRED'}
