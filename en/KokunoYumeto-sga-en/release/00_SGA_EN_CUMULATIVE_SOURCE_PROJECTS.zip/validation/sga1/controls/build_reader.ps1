$ErrorActionPreference='Stop'
$taskRoot=Split-Path -Parent $PSScriptRoot
$guard=Join-Path $PSScriptRoot 'run_guarded_process.ps1'
$engine=(Get-Command pdflatex.exe).Source
$utf8=[Text.UTF8Encoding]::new($false)
$resultPath=Join-Path $taskRoot 'BUILD_RESULT.json'
if(Test-Path -LiteralPath $resultPath){throw 'Immutable attempt already exists'}
$p=Get-Content -LiteralPath (Join-Path $taskRoot 'PREPARATION.json') -Raw|ConvertFrom-Json
foreach($row in $p.inputs){
 if((Get-FileHash -LiteralPath $row.path).Hash -ne $row.sha256){throw 'Live source drift'}
 foreach($variant in 'primary','replay'){
  if((Get-FileHash -LiteralPath (Join-Path $taskRoot "build/$variant/$($row.relative)")).Hash -ne $row.sha256){throw 'Staged source drift'}
 }
}
if((Get-FileHash -LiteralPath (Join-Path $taskRoot "build/direct/$($p.master)")).Hash -ne $p.direct_tex.sha256){throw 'Direct TEX drift'}
$mutex=[Threading.Mutex]::new($false,'Global\InterlanguageTeXSlotV1')
$owned=$false;$abandoned=$false;$failure=$null;$passes=@();$saved=@{}
foreach($v in 'TEMP','TMP','SOURCE_DATE_EPOCH','FORCE_SOURCE_DATE','TZ','MIKTEX_ENABLE_INSTALLER'){$saved[$v]=[Environment]::GetEnvironmentVariable($v,'Process')}
$tempDir=Join-Path $taskRoot 'tmp';[IO.Directory]::CreateDirectory($tempDir)|Out-Null
$env:TEMP=$tempDir;$env:TMP=$tempDir;$env:SOURCE_DATE_EPOCH='1790294400';$env:FORCE_SOURCE_DATE='1';$env:TZ='UTC';$env:MIKTEX_ENABLE_INSTALLER='0'
try{
 try{$owned=$mutex.WaitOne(1000)}catch [Threading.AbandonedMutexException]{$owned=$true;$abandoned=$true}
 if(-not $owned){throw 'TeX mutex unavailable; no worker launched'}
 foreach($edition in 'primary','replay','direct'){
  $work=Join-Path $taskRoot "build/$edition"
  foreach($pass in 1..3){
   Write-Output "$edition pass $pass"
   $receipt=Join-Path $work "pass$pass.guard.json"
   & $guard -FilePath $engine -ArgumentList @('-no-shell-escape','-interaction=nonstopmode','-halt-on-error','-file-line-error','-recorder',$p.master) -WorkingDirectory $work -ReceiptPath $receipt -TimeoutSeconds 600|Out-Null
   $g=Get-Content -LiteralPath $receipt -Raw|ConvertFrom-Json
   if($g.status -ne 'SUCCEEDED' -or $g.cap_triggered -or $g.final_active_processes -ne 0){throw 'Guard failure'}
   $passes+=@{edition=$edition;pass=$pass;guard=$receipt;peak_bytes=$g.peak_job_memory_used_bytes}
  }
  $stem=[IO.Path]::GetFileNameWithoutExtension($p.master)
  $log=[IO.File]::ReadAllText((Join-Path $work "$stem.log"))
  if($log -match '(?im)^Missing character:|undefined references|Reference .+ undefined|Citation .+ undefined|Rerun to get cross-references right|multiply[- ]defined labels|^!'){throw "Log failure: $edition"}
 }
 $hashes=@('primary','replay','direct'|ForEach-Object{(Get-FileHash -LiteralPath (Join-Path $taskRoot "build/$_/$stem.pdf")).Hash})
 if(@($hashes|Select-Object -Unique).Count -ne 1){throw 'Native/replay/direct PDF byte mismatch'}
}catch{$failure=$_.Exception.Message}
finally{
 if($owned){$mutex.ReleaseMutex()};$mutex.Dispose()
 foreach($v in $saved.Keys){[Environment]::SetEnvironmentVariable($v,$saved[$v],'Process')}
 $result=@{utc=[DateTime]::UtcNow.ToString('o');mutex='Global\InterlanguageTeXSlotV1';acquired=$owned;abandoned=$abandoned;passes=$passes;error=$failure;status=$(if($failure){'FAILED'}else{'BUILD_REPLAY_DIRECT_BYTE_IDENTITY_PASS_VISUAL_PENDING'})}
 [IO.File]::WriteAllText($resultPath,($result|ConvertTo-Json -Depth 7)+"`n",$utf8)
}
if($failure){throw $failure}
Write-Output 'BUILD_REPLAY_DIRECT_BYTE_IDENTITY_PASS_VISUAL_PENDING'
