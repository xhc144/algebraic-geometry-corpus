SGA 1 - Algebraic Coverings and the Etale Fundamental Group

Complete editable English text for the accompanying 260-page reader. Original authors and redactors remain credited in the source. Correction integration and reader/source assembly: OpenAI Codex - GPT-6 Astra, Ultra effort. Earlier translation provenance is retained; no independent human review is claimed.

The native/ directory contains 141 exact project inputs. Compile SGA1_English_source_sync_workpass.tex with pdfLaTeX three times. The verified environment was MiKTeX 26.5 / pdfTeX 1.40.29, LaTeX2e 2025-11-01; SOURCE_DATE_EPOCH=1790294400, FORCE_SOURCE_DATE=1, TZ=UTC. Use -no-shell-escape -interaction=nonstopmode -halt-on-error -recorder.

The directly downloadable SGA1_English_Cumulative.tex includes the full preamble and text using embedded filecontents* inputs. For exact reproduction, copy it into a fresh directory with the native master filename above and compile three times. Native build, independent replay and this direct-file build were byte-identical. This replaces the older flattened reading copy that could reflow paragraphs.

All project-specific dependencies are included. Standard distribution files are listed in STANDARD_TEX_DEPENDENCIES.json. No external project images or bibliography database are required by the verified build. historical/ preserves inherited build notes and inventories; the current source manifest supersedes those inventories.

English edition: https://doi.org/10.5281/zenodo.21925497
Original-language Canon: https://doi.org/10.5281/zenodo.20410947
Repository: https://github.com/KokunoYumeto/sga-en
